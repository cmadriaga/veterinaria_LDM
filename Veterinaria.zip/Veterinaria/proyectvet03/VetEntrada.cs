﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proyectvet03
{
    public partial class VetEntrada : Form
    {
        public VetEntrada()
        {
            InitializeComponent();
        }

        private void btnIngresarCliente_Click(object sender, EventArgs e)
        {
            //Ingreso minuevcliente = new Ingreso();
            //minuevcliente.Show();
            AbrirIngrcliente(new Ingreso());



        }

        private void btnbuscarcliente_Click(object sender, EventArgs e)
        {
            //BuscarCliente buscarcliente = new BuscarCliente();
            //buscarcliente.Show();
            AbrirIngrcliente(new BuscarCliente());
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btncerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void AbrirIngrcliente(object Ingrcliente)
        {
            if (this.panelcontenedor.Controls.Count > 0)
                this.panelcontenedor.Controls.RemoveAt(0);
            Form fh = Ingrcliente as Form;
            fh.TopLevel = false;
            fh.Dock = DockStyle.Fill;
            this.panelcontenedor.Controls.Add(fh);
            this.panelcontenedor.Tag = fh;
            fh.Show();

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Usuario re = new Usuario();
            re.Show();
        }

        private void Entrada_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {

        }
    }
}
