﻿namespace proyectvet03_01
{
    partial class nuevoPaciente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.txtApellido01 = new System.Windows.Forms.TextBox();
            this.lblApellido = new System.Windows.Forms.Label();
            this.txtNombre01 = new System.Windows.Forms.TextBox();
            this.lblNombre = new System.Windows.Forms.Label();
            this.txtpelaje = new System.Windows.Forms.TextBox();
            this.txtsexo = new System.Windows.Forms.TextBox();
            this.txtraza = new System.Windows.Forms.TextBox();
            this.txtespecie = new System.Windows.Forms.TextBox();
            this.txtpaciente = new System.Windows.Forms.TextBox();
            this.Btncancelar = new System.Windows.Forms.Button();
            this.BtnGuardar = new System.Windows.Forms.Button();
            this.lblultivisita = new System.Windows.Forms.Label();
            this.lblpelaje = new System.Windows.Forms.Label();
            this.lblfechanacimiento = new System.Windows.Forms.Label();
            this.lblsexo = new System.Windows.Forms.Label();
            this.lblRaza = new System.Windows.Forms.Label();
            this.lblespecie = new System.Windows.Forms.Label();
            this.lblpaciente = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(219, 275);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 50;
            // 
            // txtApellido01
            // 
            this.txtApellido01.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtApellido01.Location = new System.Drawing.Point(599, 22);
            this.txtApellido01.Name = "txtApellido01";
            this.txtApellido01.Size = new System.Drawing.Size(171, 26);
            this.txtApellido01.TabIndex = 46;
            // 
            // lblApellido
            // 
            this.lblApellido.AutoSize = true;
            this.lblApellido.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblApellido.Location = new System.Drawing.Point(410, 25);
            this.lblApellido.Name = "lblApellido";
            this.lblApellido.Size = new System.Drawing.Size(125, 20);
            this.lblApellido.TabIndex = 45;
            this.lblApellido.Text = "Apellido Dueño :";
            // 
            // txtNombre01
            // 
            this.txtNombre01.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombre01.Location = new System.Drawing.Point(219, 22);
            this.txtNombre01.Name = "txtNombre01";
            this.txtNombre01.Size = new System.Drawing.Size(171, 26);
            this.txtNombre01.TabIndex = 44;
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre.Location = new System.Drawing.Point(30, 25);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(125, 20);
            this.lblNombre.TabIndex = 43;
            this.lblNombre.Text = "Nombre Dueño :";
            // 
            // txtpelaje
            // 
            this.txtpelaje.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpelaje.Location = new System.Drawing.Point(219, 233);
            this.txtpelaje.Name = "txtpelaje";
            this.txtpelaje.Size = new System.Drawing.Size(117, 26);
            this.txtpelaje.TabIndex = 42;
            // 
            // txtsexo
            // 
            this.txtsexo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsexo.Location = new System.Drawing.Point(219, 192);
            this.txtsexo.Name = "txtsexo";
            this.txtsexo.Size = new System.Drawing.Size(74, 26);
            this.txtsexo.TabIndex = 41;
            // 
            // txtraza
            // 
            this.txtraza.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtraza.Location = new System.Drawing.Point(219, 159);
            this.txtraza.Name = "txtraza";
            this.txtraza.Size = new System.Drawing.Size(117, 26);
            this.txtraza.TabIndex = 40;
            // 
            // txtespecie
            // 
            this.txtespecie.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtespecie.Location = new System.Drawing.Point(219, 116);
            this.txtespecie.Name = "txtespecie";
            this.txtespecie.Size = new System.Drawing.Size(117, 26);
            this.txtespecie.TabIndex = 39;
            // 
            // txtpaciente
            // 
            this.txtpaciente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpaciente.Location = new System.Drawing.Point(219, 76);
            this.txtpaciente.Name = "txtpaciente";
            this.txtpaciente.Size = new System.Drawing.Size(171, 26);
            this.txtpaciente.TabIndex = 38;
            // 
            // Btncancelar
            // 
            this.Btncancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btncancelar.Location = new System.Drawing.Point(350, 392);
            this.Btncancelar.Name = "Btncancelar";
            this.Btncancelar.Size = new System.Drawing.Size(98, 37);
            this.Btncancelar.TabIndex = 37;
            this.Btncancelar.Text = "SALIR";
            this.Btncancelar.UseVisualStyleBackColor = true;
            this.Btncancelar.Click += new System.EventHandler(this.Btncancelar_Click);
            // 
            // BtnGuardar
            // 
            this.BtnGuardar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnGuardar.Location = new System.Drawing.Point(34, 392);
            this.BtnGuardar.Name = "BtnGuardar";
            this.BtnGuardar.Size = new System.Drawing.Size(98, 37);
            this.BtnGuardar.TabIndex = 36;
            this.BtnGuardar.Text = "Guardar";
            this.BtnGuardar.UseVisualStyleBackColor = true;
            this.BtnGuardar.Click += new System.EventHandler(this.BtnGuardar_Click);
            // 
            // lblultivisita
            // 
            this.lblultivisita.AutoSize = true;
            this.lblultivisita.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblultivisita.Location = new System.Drawing.Point(35, 320);
            this.lblultivisita.Name = "lblultivisita";
            this.lblultivisita.Size = new System.Drawing.Size(97, 20);
            this.lblultivisita.TabIndex = 35;
            this.lblultivisita.Text = "Ultima Visita";
            // 
            // lblpelaje
            // 
            this.lblpelaje.AutoSize = true;
            this.lblpelaje.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpelaje.Location = new System.Drawing.Point(30, 233);
            this.lblpelaje.Name = "lblpelaje";
            this.lblpelaje.Size = new System.Drawing.Size(52, 20);
            this.lblpelaje.TabIndex = 34;
            this.lblpelaje.Text = "Pelaje";
            // 
            // lblfechanacimiento
            // 
            this.lblfechanacimiento.AutoSize = true;
            this.lblfechanacimiento.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfechanacimiento.Location = new System.Drawing.Point(30, 275);
            this.lblfechanacimiento.Name = "lblfechanacimiento";
            this.lblfechanacimiento.Size = new System.Drawing.Size(159, 20);
            this.lblfechanacimiento.TabIndex = 32;
            this.lblfechanacimiento.Text = "Fecha de Nacimiento";
            // 
            // lblsexo
            // 
            this.lblsexo.AutoSize = true;
            this.lblsexo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsexo.Location = new System.Drawing.Point(30, 192);
            this.lblsexo.Name = "lblsexo";
            this.lblsexo.Size = new System.Drawing.Size(42, 20);
            this.lblsexo.TabIndex = 31;
            this.lblsexo.Text = "sexo";
            // 
            // lblRaza
            // 
            this.lblRaza.AutoSize = true;
            this.lblRaza.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRaza.Location = new System.Drawing.Point(30, 159);
            this.lblRaza.Name = "lblRaza";
            this.lblRaza.Size = new System.Drawing.Size(47, 20);
            this.lblRaza.TabIndex = 30;
            this.lblRaza.Text = "Raza";
            // 
            // lblespecie
            // 
            this.lblespecie.AutoSize = true;
            this.lblespecie.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblespecie.Location = new System.Drawing.Point(30, 119);
            this.lblespecie.Name = "lblespecie";
            this.lblespecie.Size = new System.Drawing.Size(66, 20);
            this.lblespecie.TabIndex = 29;
            this.lblespecie.Text = "Especie";
            // 
            // lblpaciente
            // 
            this.lblpaciente.AutoSize = true;
            this.lblpaciente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpaciente.Location = new System.Drawing.Point(30, 79);
            this.lblpaciente.Name = "lblpaciente";
            this.lblpaciente.Size = new System.Drawing.Size(155, 20);
            this.lblpaciente.TabIndex = 28;
            this.lblpaciente.Text = "Nombre del paciente";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(219, 320);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker2.TabIndex = 51;
            // 
            // nuevoPaciente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.txtApellido01);
            this.Controls.Add(this.lblApellido);
            this.Controls.Add(this.txtNombre01);
            this.Controls.Add(this.lblNombre);
            this.Controls.Add(this.txtpelaje);
            this.Controls.Add(this.txtsexo);
            this.Controls.Add(this.txtraza);
            this.Controls.Add(this.txtespecie);
            this.Controls.Add(this.txtpaciente);
            this.Controls.Add(this.Btncancelar);
            this.Controls.Add(this.BtnGuardar);
            this.Controls.Add(this.lblultivisita);
            this.Controls.Add(this.lblpelaje);
            this.Controls.Add(this.lblfechanacimiento);
            this.Controls.Add(this.lblsexo);
            this.Controls.Add(this.lblRaza);
            this.Controls.Add(this.lblespecie);
            this.Controls.Add(this.lblpaciente);
            this.Name = "nuevoPaciente";
            this.Text = "nuevoPaciente";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        public System.Windows.Forms.TextBox txtApellido01;
        private System.Windows.Forms.Label lblApellido;
        public System.Windows.Forms.TextBox txtNombre01;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.TextBox txtpelaje;
        private System.Windows.Forms.TextBox txtsexo;
        private System.Windows.Forms.TextBox txtraza;
        private System.Windows.Forms.TextBox txtespecie;
        private System.Windows.Forms.TextBox txtpaciente;
        private System.Windows.Forms.Button Btncancelar;
        private System.Windows.Forms.Button BtnGuardar;
        private System.Windows.Forms.Label lblultivisita;
        private System.Windows.Forms.Label lblpelaje;
        private System.Windows.Forms.Label lblfechanacimiento;
        private System.Windows.Forms.Label lblsexo;
        private System.Windows.Forms.Label lblRaza;
        private System.Windows.Forms.Label lblespecie;
        private System.Windows.Forms.Label lblpaciente;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
    }
}