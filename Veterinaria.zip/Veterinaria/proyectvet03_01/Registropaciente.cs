﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proyectvet03_01
{
    public partial class Registropaciente : Form
    {
        public Registropaciente()
        {
            InitializeComponent();
        }

        private void Btncancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnGuardar_Click(object sender, EventArgs e)
        {
            CPaciente paciente = new CPaciente();

            paciente.Nombre = txtNombre01.Text;
            paciente.Apellido = txtApellido01.Text;
            paciente.paciente = txtpaciente.Text;
            paciente.especie = txtespecie.Text;
            paciente.raza = txtraza.Text;
            paciente.sexo = txtsexo.Text;
            paciente.pelaje = txtpelaje.Text;
            paciente.fechanacimiento = Convert.ToString(dateTimePicker1.Value);
            paciente.fechaultimavisita = Convert.ToString(dateTimePicker2.Value);



            int resultado = pacienteDAL.Agregar(paciente);

            if (resultado > 0)
            {
                MessageBox.Show("Datos Guardados Correctamente", "Datos Guardados", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("No se guardo los datos", "Error al Guardar", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

        }
    }
}
