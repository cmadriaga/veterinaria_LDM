﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace proyectvet01
{
    public class ClienteDAL
    {
        public static int Agregar(Ccliente pcliente)
        {

            int retorno = 0;
            using (SqlConnection Conn = BDComun.ObtenerCOnexion())
            {

                SqlCommand comando = new SqlCommand(string.Format("Insert Into clientes ( Nombre, Apellido, Direccion, Fecha_Ingreso) Values('{0}','{1}','{2}','{3}')",
                  pcliente.Nombre, pcliente.Apellido, pcliente.Direccion, pcliente.Fecha_Ingreso), Conn);

                retorno = comando.ExecuteNonQuery();
            }
            return retorno;
        }

        public static List<Ccliente> BuscarCliente(string pNombre, string pApellido)
        {
            List<Ccliente> lista = new List<Ccliente>();
            using (SqlConnection conexion = BDComun.ObtenerCOnexion())
            {
                SqlCommand comando = new SqlCommand(string.Format(
                   "Select Id, Nombre, Apellido, Direccion, Fecha_Ingreso from clientes where Nombre LIKE '%{0}%' and Apellido LIKE '%{1}%'", pNombre, pApellido), conexion);


                SqlDataReader reader = comando.ExecuteReader();

                while (reader.Read())
                {
                    Ccliente pcliente = new Ccliente();
                    pcliente.Id = reader.GetInt64(0);
                    pcliente.Nombre = reader.GetString(1);
                    pcliente.Apellido = reader.GetString(2);
                    pcliente.Direccion = reader.GetString(3);
                    pcliente.Fecha_Ingreso = Convert.ToString(reader.GetDateTime(4));

                    lista.Add(pcliente);

                }

                conexion.Close();
            }
            return lista;

        }

        public static Ccliente ObtenerCliente(Int64 pId)
        {

            using (SqlConnection conexion = BDComun.ObtenerCOnexion())
            {
                Ccliente pcliente = new Ccliente();
                SqlCommand comando = new SqlCommand(string.Format(
                   "Select Id, Nombre, Apellido, Direccion, Fecha_Ingreso from clientes where   Id={0}", pId), conexion);


                SqlDataReader reader = comando.ExecuteReader();

                while (reader.Read())
                {

                    pcliente.Id = reader.GetInt64(0);
                    pcliente.Nombre = reader.GetString(1);
                    pcliente.Apellido = reader.GetString(2);
                    pcliente.Direccion = reader.GetString(3);
                    pcliente.Fecha_Ingreso = Convert.ToString(reader.GetDateTime(4));

                }

                conexion.Close();
                return pcliente;

            }


        }

        public static int Modificar(Ccliente pcliente)
        {
            int retorno = 0;

            using (SqlConnection conexion = BDComun.ObtenerCOnexion())
            {

                SqlCommand comando = new SqlCommand(string.Format(
                  "Update  clientes set Nombre ='{0}', Apellido = '{1}', Direccion = '{2}', Fecha_Ingreso= '{3}' where Id={4} ",
                  pcliente.Nombre, pcliente.Apellido, pcliente.Direccion, Convert.ToDateTime(pcliente.Fecha_Ingreso), pcliente.Id), conexion);
                retorno = comando.ExecuteNonQuery();
                conexion.Close();
            }
            return retorno;

        }

        public static int Eliminar(Int64 pId)
        {
            int retorno = 0;
            using (SqlConnection conexion = BDComun.ObtenerCOnexion())
            {
                SqlCommand comando = new SqlCommand(string.Format(
                    "Delete from clientes where Id = {0}", pId), conexion);
                retorno = comando.ExecuteNonQuery();
                conexion.Close();
            }
            return retorno;

        }


    }



}
