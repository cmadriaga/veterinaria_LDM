﻿using System;
using System.Windows.Forms;

namespace proyectvet01
{
    public partial class Autenticacion : Form
    {
        public Autenticacion()
        {
            InitializeComponent();
        }

        private void btnentrar_Click(object sender, EventArgs e)
        {
            if (UsuarioDal.Autenticar(txtusuario.Text, txtContraseña.Text) > 0)
            {
                this.Hide();
                Entrada f = new Entrada();
                f.ShowDialog();


            }
            else
                MessageBox.Show("Error en los datos");
        }

        private void btncancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
