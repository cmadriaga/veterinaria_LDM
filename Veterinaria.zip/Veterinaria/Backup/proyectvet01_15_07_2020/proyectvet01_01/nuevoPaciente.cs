﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace proyectvet01
{
    public partial class nuevoPaciente : Form
    {
       

        public nuevoPaciente()
        {
            InitializeComponent();
           
           
        }

      

        private void btncancelar_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {

            CPaciente paciente = new CPaciente();

            paciente.Nombre = txtNombre01.Text;
            paciente.Apellido = txtApellido01.Text;
            //paciente.DNI = ;
            paciente.paciente = txtpaciente.Text;
            paciente.especie = txtespecie.Text;
            paciente.raza = txtraza.Text;
            paciente.sexo = txtsexo.Text;
            paciente.fechanacimiento = mtbfechanacimiento.Text;
            paciente.fechaalta = mtbfechaalta.Text;
            paciente.pelaje = txtpelaje.Text;
            paciente.fechaultimavisita = mtbultimavisita.Text;



            int resultado = pacienteDAL.Agregar(paciente);

            if (resultado > 0)
            {
                MessageBox.Show("Datos Guardados Correctamente", "Datos Guardados", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("No se guardo los datos", "Error al Guardar", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


        }

        private void nuevoPaciente_Load(object sender, EventArgs e)
        {

        }

        


    }
}
