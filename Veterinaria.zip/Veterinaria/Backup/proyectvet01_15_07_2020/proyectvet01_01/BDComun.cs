﻿using System.Data.SqlClient;

namespace proyectvet01
{
    public class BDComun
    {
        public static SqlConnection ObtenerCOnexion()
        {
            SqlConnection Conn = new SqlConnection("Data Source=G40\\MSSQLSERVERG40; Initial Catalog=clienteveter1;Integrated Security=True");
            Conn.Open();
            // si va la base de datos con usuario y contraseña
            // "Data Source=G40\\MSSQLSERVERG40; Initial Catalog=clienteveter1;User = blabla; Password= xxxx
            return Conn;

        }

    }
}
