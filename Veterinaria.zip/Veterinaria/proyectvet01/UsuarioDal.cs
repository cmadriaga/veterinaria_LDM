﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace proyectvet01
{
    class UsuarioDal
    {
        public static int CrearCuentas(string pUsuario, string pContraseña)
        {
            int resultado = 0;
            SqlConnection Conn = BDComun.ObtenerCOnexion();
            SqlCommand comando = new SqlCommand(string.Format("Insert into Usuarios (Nombre, Contraseña) Values('{0}', PwdEncrypt('{1}'))", pUsuario, pContraseña), Conn);

                resultado = comando.ExecuteNonQuery();
            Conn.Close();

            return resultado;

        }

        public static int Autenticar(string pUsuario, string pContraseña)
        {
            int resultado = -1;

            SqlConnection Conn = BDComun.ObtenerCOnexion();
            SqlCommand comando = new SqlCommand(string.Format(
                "Select * From  Usuarios where Nombre = '{0}' and PwdCompare('{1}', Contraseña) = 1  ", pUsuario, pContraseña), Conn);

            SqlDataReader reader = comando.ExecuteReader();
            while(reader.Read())
            {
                resultado = 128;
            }

            Conn.Close();
            return resultado;


        }

    }
}
