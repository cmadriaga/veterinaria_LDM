﻿using System;

namespace proyectvet03_01
{
    public class Ccliente
    {
        public Int64 Id { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string DNI { get; set; }
        public string Telefono { get; set; }
        public string celu { get; set; }
        public string Direccion { get; set; }
        public string Localidad { get; set; }
        public string Provincia { get; set; }
        public string Fecha_Ingreso { get; set; }
        public string Fecha_Egreso { get; set; }

        public Ccliente() { }


        public Ccliente(Int64 pId, string pNombre, string pApellido, string pDni, string pTelefono, string pCelu,
            string pDireccion, string pLocalidad, string pProvincia, string pFecha_Ingreso, string pFecha_Egreso)
        //  public Ccliente(Int64 pId, string pNombre, string pApellido, string pDni, string pTelefono, string pCelu, string pDireccion, string pFecha_Ingreso)
        ////
            {
            this.Id = pId;
            this.Nombre = pNombre;
            this.Apellido = pApellido;
            this.DNI = pDni;
            this.Telefono = pTelefono;
            this.celu = pCelu;
            this.Direccion = pDireccion;
            this.Localidad = pLocalidad;
            this.Provincia = pProvincia;
            this.Fecha_Ingreso = pFecha_Ingreso;
            this.Fecha_Egreso = pFecha_Egreso;

        }

    }
}
