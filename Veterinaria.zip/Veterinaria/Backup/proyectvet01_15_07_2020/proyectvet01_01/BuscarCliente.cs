﻿using System;
using System.Windows.Forms;

namespace proyectvet01
{
    public partial class BuscarCliente : Form
    {
        public BuscarCliente()
        {
            InitializeComponent();
        }

        public Ccliente clienteseleccionado { get; set; }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ClienteDAL.BuscarCliente(txtNombre.Text, txtApellido.Text);
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 1)
            {
                Int64 Id = Convert.ToInt64(dataGridView1.CurrentRow.Cells[0].Value);
                clienteseleccionado = ClienteDAL.ObtenerCliente(Id);
                this.Close();


            }
            else
            {
                MessageBox.Show("Ahun no se selecciono a ningun Cliente");
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
