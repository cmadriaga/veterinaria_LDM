﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace proyectvet03_01
{
    public partial class laboratorio : Form
    {
        public laboratorio()
        {
            InitializeComponent();
        }

        private void splitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.InitialDirectory = "c:\\";
            openFileDialog1.Filter = "Todos los archivos (*.*)|*.*";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;

            if(openFileDialog1.ShowDialog()== DialogResult.OK)
            {
                txtfile.Text = openFileDialog1.FileName;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (txtname.Text.Trim().Equals("")||txtfile.Text.Trim().Equals(""))
            {
                MessageBox.Show("El nombre es obligatorio");
                return;
            }

            byte[] file = null;
            Stream myStream = openFileDialog1.OpenFile();

            using (MemoryStream ms= new MemoryStream())
            {
                myStream.CopyTo(ms);
                file = ms.ToArray();
            }


            using (Lab.clienteveter1Entities1 db=new Lab.clienteveter1Entities1())
            {
                try 
                {
                 
                Lab.Laboratorio_sangre laboratorio_ = new Lab.Laboratorio_sangre();
                laboratorio_.Name = txtname.Text.Trim();
                laboratorio_.doc = file;
                laboratorio_.realName = openFileDialog1.SafeFileName;

                db.Laboratorio_sangre.Add(laboratorio_);
                db.SaveChanges();

                }
                catch
                {
                    MessageBox.Show("me parece que no se grabo");
                }
                
            }
            Refresh();
        }

        private void Refresh()
        {
            using (Lab.clienteveter1Entities1 db = new Lab.clienteveter1Entities1())
            {

                var lst = from d in db.Laboratorio_sangre
                    select new {d.Id, d.Name};
                dgvlista.DataSource = lst.ToList();
            }
                
        }

        private void laboratorio_Load(object sender, EventArgs e)
        {
            Refresh();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (dgvlista.Rows.Count > 0)
            {
                int id = int.Parse(dgvlista.Rows[dgvlista.CurrentRow.Index].Cells[0].Value.ToString());

                using (Lab.clienteveter1Entities1 db = new Lab.clienteveter1Entities1())
                {
                    var laboratorio_ = db.Laboratorio_sangre.Find(id);

                    string path = AppDomain.CurrentDomain.BaseDirectory;
                    string folder = path + "/temp/";
                    string fullfilePath = folder + laboratorio_.realName;

                    if (!Directory.Exists(folder))
                        Directory.CreateDirectory(folder);

                    if (File.Exists(fullfilePath))
                        Directory.Delete(fullfilePath);

                    File.WriteAllBytes(fullfilePath, laboratorio_.doc);

                    Process.Start(fullfilePath);


                }

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
