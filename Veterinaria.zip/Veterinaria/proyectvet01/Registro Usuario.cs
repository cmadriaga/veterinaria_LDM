﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proyectvet01
{
    public partial class Usuario : Form
    {
        public Usuario()
        {
            InitializeComponent();
        }

        private void BtnRegistrar_Click(object sender, EventArgs e)
        {
            if (txtcontraseña.Text == txtconfircontraseña.Text)
            {
                if (UsuarioDal.CrearCuentas(txtusuario.Text, txtcontraseña.Text) > 0)
                {
                    MessageBox.Show("cuenta creada con exito");
                }
                else
                    MessageBox.Show("no se creo el usuario");
            }
        }

        private void btncancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
