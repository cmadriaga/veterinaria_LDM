﻿using System;

namespace proyectvet03_01
{
    public class CPaciente
    {
        public Int64 Id { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string paciente { get; set; }
        public string especie { get; set; }
        public string raza { get; set; }
        public string sexo { get; set; }
        public string pelaje { get; set; }
        public string fechanacimiento { get; set; }
        public string fechaultimavisita { get; set; }



        public CPaciente() { }

        public CPaciente(Int64 pId, string pNombre, string pApellido, string ppaciente, string pespecie, string praza, string psexo, string ppelaje, string pfechanacimiento, string pultimavisita)
        {
            this.Id = pId;
            this.Nombre = pNombre;
            this.Apellido = pApellido;
            this.paciente = ppaciente;
            this.especie = pespecie;
            this.raza = praza;
            this.sexo = psexo;
            this.pelaje = ppelaje;
            this.fechanacimiento = pfechanacimiento;
            this.fechaultimavisita = pultimavisita;

        }
    }
}
