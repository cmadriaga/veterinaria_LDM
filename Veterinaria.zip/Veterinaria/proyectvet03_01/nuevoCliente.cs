﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proyectvet03_01
{
    public partial class nuevoCliente : Form
    {
        public nuevoCliente()
        {
            InitializeComponent();
        }

        public Ccliente clienteactual { get; set; }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            Ccliente cliente = new Ccliente();
            cliente.Nombre = txtNombre.Text;
            cliente.Apellido = txtApellido.Text;
            cliente.DNI = txtDNI.Text;
            cliente.Telefono = txttelefono.Text;
            cliente.celu = txtCelular.Text;
            cliente.Direccion = txtDireccion.Text;
            cliente.Localidad = txtlocalidad.Text;
            cliente.Provincia = txtProvincia.Text;
            cliente.Fecha_Ingreso = Convert.ToString(dateTimePicker1.Value);
            cliente.Fecha_Egreso = Convert.ToString(dateTimePicker2.Value);



            int resultado = ClienteDAL.Agregar(cliente);

            if (resultado > 0)
            {
                MessageBox.Show("datos guardados correctamente", "Datos Guardados", MessageBoxButtons.OK, MessageBoxIcon.Information);

                Limpiar();
            }
            else
            {
                MessageBox.Show("error al guardar los datos ", "Error al Guardar", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            }
        }

        void Limpiar()
        {
            txtNombre.Clear();
            txtApellido.Clear();
            txtDNI.Clear();
            txttelefono.Clear();
            txtCelular.Clear();
            txtDireccion.Clear();
            txtlocalidad.Clear();
            txtProvincia.Clear();
            
          
        }

        private void btneliminar_Click(object sender, EventArgs e)
        {
            // esto funciona si tenemos el cliente actual seleccionado
            //if (MessageBox.Show(" Seguro de eliminar el cliente ??", "Esta seguro", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK)
            //{
            //    int resultado = ClienteDAL.Eliminar(clienteactual.Id);
            //    if (resultado > 0)
            //    {
            //        MessageBox.Show(" Cliente Eliminado con exito", "Cliente Eliminado", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //        Limpiar();
            //        btneliminar.Enabled = false;
            //        btnModificar.Enabled = false;
            //        btnGuardar.Enabled = true;
            //    }
            //    else
            //    {
            //        MessageBox.Show(" Cliente no Eliminado", "Cliente no Eliminado", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            //    }
            //}
            //else
            //{
            //    MessageBox.Show("Se cancelo la eliminacion", " Cancelado ", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            //}
        }

        private void btnBuscarCliente_Click(object sender, EventArgs e)
        {
            BuscarCliente pbuscar = new BuscarCliente();
            pbuscar.ShowDialog();

            if (pbuscar.clienteseleccionado != null)
            {
                clienteactual = pbuscar.clienteseleccionado;

                txtNombre.Text = pbuscar.clienteseleccionado.Nombre;
                txtApellido.Text = pbuscar.clienteseleccionado.Apellido;
                txtDNI.Text = pbuscar.clienteseleccionado.DNI;
                txttelefono.Text = pbuscar.clienteseleccionado.Telefono;
                txtCelular.Text = pbuscar.clienteseleccionado.celu;
                txtDireccion.Text = pbuscar.clienteseleccionado.Direccion;
                txtlocalidad.Text = pbuscar.clienteseleccionado.Localidad;
                txtProvincia.Text = pbuscar.clienteseleccionado.Provincia;
                dateTimePicker1.Value = Convert.ToDateTime(pbuscar.clienteseleccionado.Fecha_Ingreso);
                dateTimePicker2.Value = Convert.ToDateTime(pbuscar.clienteseleccionado.Fecha_Egreso);

                btnGuardar.Enabled = false;
                btnModificar.Enabled = true;
                btneliminar.Enabled = true;

            }
        }

        private void btnCerrrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnnuevopaciente_Click(object sender, EventArgs e)
        {
            nuevoPaciente nuevpacient = new nuevoPaciente();
            nuevpacient.txtNombre01.Text = txtNombre.Text;
            nuevpacient.txtApellido01.Text = txtApellido.Text;

            nuevpacient.Show();
        }
    }
}
