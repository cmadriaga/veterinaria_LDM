﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace proyectvet03_01
{
    public partial class Estudios : Form
    {
        public Estudios()
        {
            InitializeComponent();
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            try
            {

                openFileDialog1.InitialDirectory = "C:\\";
                openFileDialog1.Filter = "Todos los archivos(*.*)|*.*";
                openFileDialog1.FilterIndex = 1;
                openFileDialog1.RestoreDirectory = true;

                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    txtfile.Text = openFileDialog1.FileName;
                }

            }
            catch 
            {
                MessageBox.Show("no se puede leer la ruta");
            }
           

        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (txtName.Text.Trim().Equals("") || txtfile.Text.Trim().Equals(""))
            {
                MessageBox.Show("el nombre es obligatorio");
                return;
            }

            byte[] file = null;
            Stream mystream = openFileDialog1.OpenFile();
            using (MemoryStream ms = new MemoryStream())
            {
                mystream.CopyTo(ms);
                file = ms.ToArray();
            }
            // aca recien se guarda en la base de datos

            //using (Analisis.clienteveter1Entities4 db = new Analisis.clienteveter1Entities4())
            //{
                
                    
                

            //}


        }
    }
}
