﻿using System;
using System.Windows.Forms;

namespace proyectvet01
{
    public partial class Ingreso : Form
    {


        public Ingreso()
        {
            InitializeComponent();
        }

        public Ccliente clienteactual { get; set; }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            Ccliente cliente = new Ccliente();
            cliente.Nombre = txtNombre.Text;
            cliente.Apellido = txtApellido.Text;
            cliente.Direccion = txtDireccion.Text;
            cliente.Fecha_Ingreso = txtFechaIngreso.Text;



            int resultado = ClienteDAL.Agregar(cliente);

            if (resultado > 0)
            {
                MessageBox.Show("datos guardados correctamente", "Datos Guardados", MessageBoxButtons.OK, MessageBoxIcon.Information);

                Limpiar();
            }
            else
            {
                MessageBox.Show("error al guardar los datos ", "Error al Guardar", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            }




        }

        private void btnCerrrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnBuscarCliente_Click(object sender, EventArgs e)
        {

            BuscarCliente pbuscar = new BuscarCliente();
            pbuscar.ShowDialog();

            if (pbuscar.clienteseleccionado != null)
            {
                clienteactual = pbuscar.clienteseleccionado;

                txtNombre.Text = pbuscar.clienteseleccionado.Nombre;
                txtApellido.Text = pbuscar.clienteseleccionado.Apellido;
                txtDireccion.Text = pbuscar.clienteseleccionado.Direccion;
                txtFechaIngreso.Text = pbuscar.clienteseleccionado.Fecha_Ingreso;

                btnGuardar.Enabled = false;
                btnModificar.Enabled = true;
                btneliminar.Enabled = true;

            }
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            Ccliente pcliente = new Ccliente();
            pcliente.Nombre = txtNombre.Text;
            pcliente.Apellido = txtApellido.Text;
            pcliente.Direccion = txtDireccion.Text;
            pcliente.Fecha_Ingreso = txtFechaIngreso.Text;
            pcliente.Id = clienteactual.Id;

            int resultado = ClienteDAL.Modificar(pcliente);
            if (resultado > 0)
            {
                MessageBox.Show(" Cliente Modificado con exito", "Cliente modificado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Limpiar();
                btneliminar.Enabled = false;
                btnModificar.Enabled = false;
                btnGuardar.Enabled = true;
            }
            else
            {
                MessageBox.Show(" Cliente no modificado", "Cliente no modificado", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            }
        }

        void Limpiar()
        {
            txtNombre.Clear();
            txtApellido.Clear();
            txtDireccion.Clear();
            txtFechaIngreso.Clear();

        }

        private void Ingreso_Load(object sender, EventArgs e)
        {
            btnModificar.Enabled = false;
            btneliminar.Enabled = false;
        }

        private void btneliminar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(" Seguro de eliminar el cliente ??", "Esta seguro", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK)
            {
                int resultado = ClienteDAL.Eliminar(clienteactual.Id);
                if (resultado > 0)
                {
                    MessageBox.Show(" Cliente Eliminado con exito", "Cliente Eliminado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Limpiar();
                    btneliminar.Enabled = false;
                    btnModificar.Enabled = false;
                    btnGuardar.Enabled = true;
                }
                else
                {
                    MessageBox.Show(" Cliente no Eliminado", "Cliente no Eliminado", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

                }
            }
            else
            {
                MessageBox.Show("Se cancelo la eliminacion", " Cancelado ", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Usuario re = new Usuario();
            re.Show();
        }

        private void btnnuevopaciente_Click(object sender, EventArgs e)
        {

            nuevoPaciente nuevpacient = new nuevoPaciente();
            nuevpacient.txtNombre01.Text = txtNombre.Text;
            nuevpacient.txtApellido01.Text = txtApellido.Text;

            nuevpacient.Show();
           
        }

        private void cbActual_CheckedChanged(object sender, EventArgs e)
        {
            DateTime fecha = DateTime.Today;
            txtFechaIngreso.Text = fecha.ToString("dd/MM/yyyy");
        }

        
        
        
    }
}
