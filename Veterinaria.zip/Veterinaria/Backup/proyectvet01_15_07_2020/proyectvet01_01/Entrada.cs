﻿using System;
using System.Windows.Forms;

namespace proyectvet01
{
    public partial class Entrada : Form
    {
        public Entrada()
        {
            InitializeComponent();
        }

        private void btnIngresarCliente_Click(object sender, EventArgs e)
        {
            //Ingreso minuevcliente = new Ingreso();
            //minuevcliente.Show();
            AbrirIngrcliente(new Ingreso());



        }

        private void btnbuscarcliente_Click(object sender, EventArgs e)
        {
            //BuscarCliente buscarcliente = new BuscarCliente();
            //buscarcliente.Show();
            AbrirIngrcliente(new BuscarCliente());
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btncerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void AbrirIngrcliente(object Ingrcliente)
        {
            if (this.panelcontenedor.Controls.Count > 0)
                this.panelcontenedor.Controls.RemoveAt(0);
            Form fh = Ingrcliente as Form;
            fh.TopLevel = false;
            fh.Dock = DockStyle.Fill;
            this.panelcontenedor.Controls.Add(fh);
            this.panelcontenedor.Tag = fh;
            fh.Show();

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Usuario re = new Usuario();
            re.Show();
        }
    }
}
