﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proyectvet01
{
    public partial class Autenticacion : Form
    {
        public Autenticacion()
        {
            InitializeComponent();
        }

        private void btnentrar_Click(object sender, EventArgs e)
        {
            if(UsuarioDal.Autenticar(txtusuario.Text, txtContraseña.Text) > 0)
            {
                this.Hide();
                Ingreso f = new Ingreso();
                f.ShowDialog();
               

            }
                else
                    MessageBox.Show("Error en los datos");
        }

        private void btncancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
