﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proyectvet01
{
   public class Ccliente
    {
        public Int64 Id { get; set; }
        public string Nombre { get; set; } 
        public string Apellido { get; set; }
        public string Direccion { get; set; }
        public string Fecha_Ingreso { get; set; }

        public Ccliente() { }

  
          public Ccliente(Int64 pId, string pNombre, string pApellido, string pDireccion, string pFecha_Ingreso )
        {
            this.Id = pId;
            this.Nombre = pNombre;
            this.Apellido = pApellido;
            this.Direccion = pDireccion;
            this.Fecha_Ingreso = pFecha_Ingreso;

                }

    }
}
