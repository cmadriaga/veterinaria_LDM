﻿namespace proyectvet01
{
    partial class Entrada
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Entrada));
            this.btnIngresarCliente = new System.Windows.Forms.Button();
            this.btnbuscarcliente = new System.Windows.Forms.Button();
            this.btnBuscarCanino = new System.Windows.Forms.Button();
            this.btnIngresarcanino = new System.Windows.Forms.Button();
            this.btncerrar = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnvisitas = new System.Windows.Forms.Button();
            this.panelcontenedor = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnIngresarCliente
            // 
            this.btnIngresarCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIngresarCliente.Location = new System.Drawing.Point(12, 12);
            this.btnIngresarCliente.Name = "btnIngresarCliente";
            this.btnIngresarCliente.Size = new System.Drawing.Size(99, 51);
            this.btnIngresarCliente.TabIndex = 0;
            this.btnIngresarCliente.Text = "Nuevo Cliente";
            this.btnIngresarCliente.UseVisualStyleBackColor = true;
            this.btnIngresarCliente.Click += new System.EventHandler(this.btnIngresarCliente_Click);
            // 
            // btnbuscarcliente
            // 
            this.btnbuscarcliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbuscarcliente.Location = new System.Drawing.Point(12, 69);
            this.btnbuscarcliente.Name = "btnbuscarcliente";
            this.btnbuscarcliente.Size = new System.Drawing.Size(99, 51);
            this.btnbuscarcliente.TabIndex = 1;
            this.btnbuscarcliente.Text = "Buscar Cliente";
            this.btnbuscarcliente.UseVisualStyleBackColor = true;
            this.btnbuscarcliente.Click += new System.EventHandler(this.btnbuscarcliente_Click);
            // 
            // btnBuscarCanino
            // 
            this.btnBuscarCanino.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarCanino.Location = new System.Drawing.Point(12, 312);
            this.btnBuscarCanino.Name = "btnBuscarCanino";
            this.btnBuscarCanino.Size = new System.Drawing.Size(99, 51);
            this.btnBuscarCanino.TabIndex = 2;
            this.btnBuscarCanino.Text = "Buscar Canino";
            this.btnBuscarCanino.UseVisualStyleBackColor = true;
            // 
            // btnIngresarcanino
            // 
            this.btnIngresarcanino.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIngresarcanino.Location = new System.Drawing.Point(12, 247);
            this.btnIngresarcanino.Name = "btnIngresarcanino";
            this.btnIngresarcanino.Size = new System.Drawing.Size(99, 51);
            this.btnIngresarcanino.TabIndex = 3;
            this.btnIngresarcanino.Text = "Ingresar Canino";
            this.btnIngresarcanino.UseVisualStyleBackColor = true;
            // 
            // btncerrar
            // 
            this.btncerrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncerrar.Location = new System.Drawing.Point(12, 438);
            this.btncerrar.Name = "btncerrar";
            this.btncerrar.Size = new System.Drawing.Size(118, 51);
            this.btncerrar.TabIndex = 4;
            this.btncerrar.Text = "Cerrar";
            this.btncerrar.UseVisualStyleBackColor = true;
            this.btncerrar.Click += new System.EventHandler(this.btncerrar_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(12, 130);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(99, 51);
            this.button1.TabIndex = 5;
            this.button1.Text = "Listar Cliente";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnvisitas
            // 
            this.btnvisitas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnvisitas.Location = new System.Drawing.Point(12, 190);
            this.btnvisitas.Name = "btnvisitas";
            this.btnvisitas.Size = new System.Drawing.Size(99, 51);
            this.btnvisitas.TabIndex = 6;
            this.btnvisitas.Text = "Registro Visitas";
            this.btnvisitas.UseVisualStyleBackColor = true;
            // 
            // panelcontenedor
            // 
            this.panelcontenedor.Location = new System.Drawing.Point(149, 12);
            this.panelcontenedor.Name = "panelcontenedor";
            this.panelcontenedor.Size = new System.Drawing.Size(761, 477);
            this.panelcontenedor.TabIndex = 7;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 369);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(76, 63);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Entrada
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(922, 521);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panelcontenedor);
            this.Controls.Add(this.btnvisitas);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btncerrar);
            this.Controls.Add(this.btnIngresarcanino);
            this.Controls.Add(this.btnBuscarCanino);
            this.Controls.Add(this.btnbuscarcliente);
            this.Controls.Add(this.btnIngresarCliente);
            this.Name = "Entrada";
            this.Text = "Entrada";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnIngresarCliente;
        private System.Windows.Forms.Button btnbuscarcliente;
        private System.Windows.Forms.Button btnBuscarCanino;
        private System.Windows.Forms.Button btnIngresarcanino;
        private System.Windows.Forms.Button btncerrar;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnvisitas;
        private System.Windows.Forms.Panel panelcontenedor;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}