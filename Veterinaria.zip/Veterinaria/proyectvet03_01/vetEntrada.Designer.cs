﻿namespace proyectvet03_01
{
    partial class vetEntrada
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(vetEntrada));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panelcontenedor = new System.Windows.Forms.Panel();
            this.btnvisitas = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btncerrar = new System.Windows.Forms.Button();
            this.btnregistropaciente = new System.Windows.Forms.Button();
            this.btnBuscarCanino = new System.Windows.Forms.Button();
            this.btnbuscarcliente = new System.Windows.Forms.Button();
            this.btnIngresarCliente = new System.Windows.Forms.Button();
            this.btnEstudios = new System.Windows.Forms.Button();
            this.btnlaboratorio1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(27, 374);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(76, 63);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 24;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // panelcontenedor
            // 
            this.panelcontenedor.Location = new System.Drawing.Point(164, 77);
            this.panelcontenedor.Name = "panelcontenedor";
            this.panelcontenedor.Size = new System.Drawing.Size(761, 477);
            this.panelcontenedor.TabIndex = 23;
            // 
            // btnvisitas
            // 
            this.btnvisitas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnvisitas.Location = new System.Drawing.Point(27, 195);
            this.btnvisitas.Name = "btnvisitas";
            this.btnvisitas.Size = new System.Drawing.Size(99, 51);
            this.btnvisitas.TabIndex = 22;
            this.btnvisitas.Text = "Registro Visitas";
            this.btnvisitas.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(27, 135);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(99, 51);
            this.button1.TabIndex = 21;
            this.button1.Text = "Listar Cliente";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // btncerrar
            // 
            this.btncerrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncerrar.Location = new System.Drawing.Point(27, 458);
            this.btncerrar.Name = "btncerrar";
            this.btncerrar.Size = new System.Drawing.Size(118, 51);
            this.btncerrar.TabIndex = 20;
            this.btncerrar.Text = "Cerrar";
            this.btncerrar.UseVisualStyleBackColor = true;
            this.btncerrar.Click += new System.EventHandler(this.btncerrar_Click);
            // 
            // btnregistropaciente
            // 
            this.btnregistropaciente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnregistropaciente.Location = new System.Drawing.Point(27, 252);
            this.btnregistropaciente.Name = "btnregistropaciente";
            this.btnregistropaciente.Size = new System.Drawing.Size(99, 51);
            this.btnregistropaciente.TabIndex = 19;
            this.btnregistropaciente.Text = "Registro Paciente";
            this.btnregistropaciente.UseVisualStyleBackColor = true;
            this.btnregistropaciente.Click += new System.EventHandler(this.btnregistropaciente_Click);
            // 
            // btnBuscarCanino
            // 
            this.btnBuscarCanino.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarCanino.Location = new System.Drawing.Point(27, 317);
            this.btnBuscarCanino.Name = "btnBuscarCanino";
            this.btnBuscarCanino.Size = new System.Drawing.Size(99, 51);
            this.btnBuscarCanino.TabIndex = 18;
            this.btnBuscarCanino.Text = "Buscar Canino";
            this.btnBuscarCanino.UseVisualStyleBackColor = true;
            // 
            // btnbuscarcliente
            // 
            this.btnbuscarcliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbuscarcliente.Location = new System.Drawing.Point(27, 74);
            this.btnbuscarcliente.Name = "btnbuscarcliente";
            this.btnbuscarcliente.Size = new System.Drawing.Size(99, 51);
            this.btnbuscarcliente.TabIndex = 17;
            this.btnbuscarcliente.Text = "Buscar Cliente";
            this.btnbuscarcliente.UseVisualStyleBackColor = true;
            // 
            // btnIngresarCliente
            // 
            this.btnIngresarCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIngresarCliente.Location = new System.Drawing.Point(27, 17);
            this.btnIngresarCliente.Name = "btnIngresarCliente";
            this.btnIngresarCliente.Size = new System.Drawing.Size(99, 51);
            this.btnIngresarCliente.TabIndex = 16;
            this.btnIngresarCliente.Text = "Nuevo Cliente";
            this.btnIngresarCliente.UseVisualStyleBackColor = true;
            this.btnIngresarCliente.Click += new System.EventHandler(this.btnIngresarCliente_Click);
            // 
            // btnEstudios
            // 
            this.btnEstudios.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEstudios.Location = new System.Drawing.Point(222, 17);
            this.btnEstudios.Name = "btnEstudios";
            this.btnEstudios.Size = new System.Drawing.Size(75, 30);
            this.btnEstudios.TabIndex = 25;
            this.btnEstudios.Text = "Estudios";
            this.btnEstudios.UseVisualStyleBackColor = true;
            this.btnEstudios.Click += new System.EventHandler(this.btnEstudios_Click);
            // 
            // btnlaboratorio1
            // 
            this.btnlaboratorio1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlaboratorio1.Location = new System.Drawing.Point(321, 17);
            this.btnlaboratorio1.Name = "btnlaboratorio1";
            this.btnlaboratorio1.Size = new System.Drawing.Size(145, 30);
            this.btnlaboratorio1.TabIndex = 26;
            this.btnlaboratorio1.Text = "Laboratorio1";
            this.btnlaboratorio1.UseVisualStyleBackColor = true;
            this.btnlaboratorio1.Click += new System.EventHandler(this.btnlaboratorio1_Click);
            // 
            // vetEntrada
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(958, 568);
            this.Controls.Add(this.btnlaboratorio1);
            this.Controls.Add(this.btnEstudios);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panelcontenedor);
            this.Controls.Add(this.btnvisitas);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btncerrar);
            this.Controls.Add(this.btnregistropaciente);
            this.Controls.Add(this.btnBuscarCanino);
            this.Controls.Add(this.btnbuscarcliente);
            this.Controls.Add(this.btnIngresarCliente);
            this.Name = "vetEntrada";
            this.Text = "vetEntrada";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panelcontenedor;
        private System.Windows.Forms.Button btnvisitas;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btncerrar;
        private System.Windows.Forms.Button btnregistropaciente;
        private System.Windows.Forms.Button btnBuscarCanino;
        private System.Windows.Forms.Button btnbuscarcliente;
        private System.Windows.Forms.Button btnIngresarCliente;
        private System.Windows.Forms.Button btnEstudios;
        private System.Windows.Forms.Button btnlaboratorio1;
    }
}