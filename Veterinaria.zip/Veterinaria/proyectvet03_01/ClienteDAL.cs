﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace proyectvet03_01
{
    public class ClienteDAL
    {
        public static int Agregar(Ccliente pcliente)
        {
            
            int retorno = 0;
            using (SqlConnection Conn = BDComun.ObtenerCOnexion())
            {

                SqlCommand comando = new SqlCommand(string.Format("Insert Into clientes (Nombre, Apellido, DNI, Telefono, Celu, Direccion, Localidad, Provincia, Fecha_Ingreso, Fecha_Egreso) Values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}')",
                  pcliente.Nombre, pcliente.Apellido, pcliente.DNI, pcliente.Telefono, pcliente.celu, pcliente.Direccion, pcliente.Localidad, pcliente.Provincia, pcliente.Fecha_Ingreso, pcliente.Fecha_Egreso), Conn);

                retorno = comando.ExecuteNonQuery();
            }
            return retorno;
        }

        public static List<Ccliente> BuscarCliente(string pNombre, string pApellido)
        {
            List<Ccliente> lista = new List<Ccliente>();
            using (SqlConnection conexion = BDComun.ObtenerCOnexion())
            {
                SqlCommand comando = new SqlCommand(string.Format(
                   "Select Id, Nombre, Apellido,DNI, Telefono, Celu, Direccion, Localidad , Provincia, Fecha_Ingreso, Fecha_Egreso from clientes where Nombre LIKE '%{0}%' and Apellido LIKE '%{1}%'", pNombre, pApellido), conexion);


                SqlDataReader reader = comando.ExecuteReader();

                while (reader.Read())
                {
                    Ccliente pcliente = new Ccliente();
                    pcliente.Id = reader.GetInt64(0);
                    pcliente.Nombre = reader.GetString(1);
                    pcliente.Apellido = reader.GetString(2);
                    pcliente.DNI = reader.GetString(3);
                    pcliente.Telefono = reader.GetString(4);
                    pcliente.celu = reader.GetString(5);
                    pcliente.Direccion = reader.GetString(6);
                    pcliente.Localidad = reader.GetString(7);
                    pcliente.Provincia = reader.GetString(8);
                    pcliente.Fecha_Ingreso = reader.GetString(9);
                    pcliente.Fecha_Egreso = reader.GetString(10);

                    lista.Add(pcliente);

                }

                conexion.Close();
            }
            return lista;

        }

        public static Ccliente ObtenerCliente(Int64 pId)
        {

            using (SqlConnection conexion = BDComun.ObtenerCOnexion())
            {
                Ccliente pcliente = new Ccliente();
                SqlCommand comando = new SqlCommand(string.Format(
                   "Select Id, Nombre, Apellido, DNI, Telefono, Celu, Direccion,Localidad , Provincia, Fecha_Ingreso, Fecha_Egreso from clientes where   Id={0}", pId), conexion);


                SqlDataReader reader = comando.ExecuteReader();

                while (reader.Read())
                {

                    pcliente.Id = reader.GetInt64(0);
                    pcliente.Nombre = reader.GetString(1);
                    pcliente.Apellido = reader.GetString(2);
                    pcliente.DNI = reader.GetString(3);
                    pcliente.Telefono = reader.GetString(4);
                    pcliente.celu = reader.GetString(5);
                    pcliente.Direccion = reader.GetString(6);
                    pcliente.Localidad = reader.GetString(7);
                    pcliente.Provincia = reader.GetString(8);
                    pcliente.Fecha_Ingreso = reader.GetString(9);
                    pcliente.Fecha_Egreso = reader.GetString(10);

                }

                conexion.Close();
                return pcliente;

            }


        }

        public static int Modificar(Ccliente pcliente)
        {
            int retorno = 0;

            using (SqlConnection conexion = BDComun.ObtenerCOnexion())
            {

                SqlCommand comando = new SqlCommand(string.Format(
                  "Update  clientes set Nombre ='{0}', Apellido = '{1}', DNI = '{2}', Telefono = '{3}', Celu = '{4}', Direccion = '{5}', Localidad = '{6}', Provincia = '{7}', Fecha_Ingreso = '{8}', Fecha_Egreso = '{9}'where Id={10} ",
                  pcliente.Nombre, pcliente.Apellido, pcliente.DNI, pcliente.Telefono, pcliente.celu, pcliente.Direccion, pcliente.Localidad, pcliente.Provincia, Convert.ToDateTime(pcliente.Fecha_Ingreso), Convert.ToDateTime(pcliente.Fecha_Egreso) ,pcliente.Id), conexion);
                retorno = comando.ExecuteNonQuery();
                conexion.Close();
            }
            return retorno;

        }

        public static int Eliminar(Int64 pId)
        {
            int retorno = 0;
            using (SqlConnection conexion = BDComun.ObtenerCOnexion())
            {
                SqlCommand comando = new SqlCommand(string.Format(
                    "Delete from clientes where Id = {0}", pId), conexion);
                retorno = comando.ExecuteNonQuery();
                conexion.Close();
            }
            return retorno;

        }


    }



}
