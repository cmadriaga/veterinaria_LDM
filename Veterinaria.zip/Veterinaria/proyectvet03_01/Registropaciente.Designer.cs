﻿namespace proyectvet03_01
{
    partial class Registropaciente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtApellido01 = new System.Windows.Forms.TextBox();
            this.lblApellido = new System.Windows.Forms.Label();
            this.txtNombre01 = new System.Windows.Forms.TextBox();
            this.lblNombre = new System.Windows.Forms.Label();
            this.txtpelaje = new System.Windows.Forms.TextBox();
            this.txtsexo = new System.Windows.Forms.TextBox();
            this.txtraza = new System.Windows.Forms.TextBox();
            this.txtespecie = new System.Windows.Forms.TextBox();
            this.txtpaciente = new System.Windows.Forms.TextBox();
            this.lblpelaje = new System.Windows.Forms.Label();
            this.lblsexo = new System.Windows.Forms.Label();
            this.lblRaza = new System.Windows.Forms.Label();
            this.lblespecie = new System.Windows.Forms.Label();
            this.lblpaciente = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.Btncancelar = new System.Windows.Forms.Button();
            this.BtnGuardar = new System.Windows.Forms.Button();
            this.lblultivisita = new System.Windows.Forms.Label();
            this.lblfechanacimiento = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtApellido01
            // 
            this.txtApellido01.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtApellido01.Location = new System.Drawing.Point(605, 32);
            this.txtApellido01.Name = "txtApellido01";
            this.txtApellido01.Size = new System.Drawing.Size(171, 26);
            this.txtApellido01.TabIndex = 60;
            // 
            // lblApellido
            // 
            this.lblApellido.AutoSize = true;
            this.lblApellido.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblApellido.Location = new System.Drawing.Point(416, 35);
            this.lblApellido.Name = "lblApellido";
            this.lblApellido.Size = new System.Drawing.Size(125, 20);
            this.lblApellido.TabIndex = 59;
            this.lblApellido.Text = "Apellido Dueño :";
            // 
            // txtNombre01
            // 
            this.txtNombre01.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombre01.Location = new System.Drawing.Point(225, 32);
            this.txtNombre01.Name = "txtNombre01";
            this.txtNombre01.Size = new System.Drawing.Size(171, 26);
            this.txtNombre01.TabIndex = 58;
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre.Location = new System.Drawing.Point(36, 35);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(125, 20);
            this.lblNombre.TabIndex = 57;
            this.lblNombre.Text = "Nombre Dueño :";
            // 
            // txtpelaje
            // 
            this.txtpelaje.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpelaje.Location = new System.Drawing.Point(225, 243);
            this.txtpelaje.Name = "txtpelaje";
            this.txtpelaje.Size = new System.Drawing.Size(117, 26);
            this.txtpelaje.TabIndex = 56;
            // 
            // txtsexo
            // 
            this.txtsexo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsexo.Location = new System.Drawing.Point(225, 202);
            this.txtsexo.Name = "txtsexo";
            this.txtsexo.Size = new System.Drawing.Size(74, 26);
            this.txtsexo.TabIndex = 55;
            // 
            // txtraza
            // 
            this.txtraza.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtraza.Location = new System.Drawing.Point(225, 169);
            this.txtraza.Name = "txtraza";
            this.txtraza.Size = new System.Drawing.Size(117, 26);
            this.txtraza.TabIndex = 54;
            // 
            // txtespecie
            // 
            this.txtespecie.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtespecie.Location = new System.Drawing.Point(225, 126);
            this.txtespecie.Name = "txtespecie";
            this.txtespecie.Size = new System.Drawing.Size(117, 26);
            this.txtespecie.TabIndex = 53;
            // 
            // txtpaciente
            // 
            this.txtpaciente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpaciente.Location = new System.Drawing.Point(225, 86);
            this.txtpaciente.Name = "txtpaciente";
            this.txtpaciente.Size = new System.Drawing.Size(171, 26);
            this.txtpaciente.TabIndex = 52;
            // 
            // lblpelaje
            // 
            this.lblpelaje.AutoSize = true;
            this.lblpelaje.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpelaje.Location = new System.Drawing.Point(36, 243);
            this.lblpelaje.Name = "lblpelaje";
            this.lblpelaje.Size = new System.Drawing.Size(52, 20);
            this.lblpelaje.TabIndex = 51;
            this.lblpelaje.Text = "Pelaje";
            // 
            // lblsexo
            // 
            this.lblsexo.AutoSize = true;
            this.lblsexo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsexo.Location = new System.Drawing.Point(36, 202);
            this.lblsexo.Name = "lblsexo";
            this.lblsexo.Size = new System.Drawing.Size(42, 20);
            this.lblsexo.TabIndex = 50;
            this.lblsexo.Text = "sexo";
            // 
            // lblRaza
            // 
            this.lblRaza.AutoSize = true;
            this.lblRaza.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRaza.Location = new System.Drawing.Point(36, 169);
            this.lblRaza.Name = "lblRaza";
            this.lblRaza.Size = new System.Drawing.Size(47, 20);
            this.lblRaza.TabIndex = 49;
            this.lblRaza.Text = "Raza";
            // 
            // lblespecie
            // 
            this.lblespecie.AutoSize = true;
            this.lblespecie.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblespecie.Location = new System.Drawing.Point(36, 129);
            this.lblespecie.Name = "lblespecie";
            this.lblespecie.Size = new System.Drawing.Size(66, 20);
            this.lblespecie.TabIndex = 48;
            this.lblespecie.Text = "Especie";
            // 
            // lblpaciente
            // 
            this.lblpaciente.AutoSize = true;
            this.lblpaciente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpaciente.Location = new System.Drawing.Point(36, 89);
            this.lblpaciente.Name = "lblpaciente";
            this.lblpaciente.Size = new System.Drawing.Size(155, 20);
            this.lblpaciente.TabIndex = 47;
            this.lblpaciente.Text = "Nombre del paciente";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.CustomFormat = "dd/MM/yyyy";
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker2.Location = new System.Drawing.Point(225, 333);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(117, 20);
            this.dateTimePicker2.TabIndex = 66;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "dd/MM/yyyy";
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(225, 288);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(117, 20);
            this.dateTimePicker1.TabIndex = 65;
            // 
            // Btncancelar
            // 
            this.Btncancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btncancelar.Location = new System.Drawing.Point(356, 405);
            this.Btncancelar.Name = "Btncancelar";
            this.Btncancelar.Size = new System.Drawing.Size(98, 37);
            this.Btncancelar.TabIndex = 64;
            this.Btncancelar.Text = "SALIR";
            this.Btncancelar.UseVisualStyleBackColor = true;
            this.Btncancelar.Click += new System.EventHandler(this.Btncancelar_Click);
            // 
            // BtnGuardar
            // 
            this.BtnGuardar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnGuardar.Location = new System.Drawing.Point(40, 405);
            this.BtnGuardar.Name = "BtnGuardar";
            this.BtnGuardar.Size = new System.Drawing.Size(98, 37);
            this.BtnGuardar.TabIndex = 63;
            this.BtnGuardar.Text = "Guardar";
            this.BtnGuardar.UseVisualStyleBackColor = true;
            this.BtnGuardar.Click += new System.EventHandler(this.BtnGuardar_Click);
            // 
            // lblultivisita
            // 
            this.lblultivisita.AutoSize = true;
            this.lblultivisita.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblultivisita.Location = new System.Drawing.Point(41, 333);
            this.lblultivisita.Name = "lblultivisita";
            this.lblultivisita.Size = new System.Drawing.Size(97, 20);
            this.lblultivisita.TabIndex = 62;
            this.lblultivisita.Text = "Ultima Visita";
            // 
            // lblfechanacimiento
            // 
            this.lblfechanacimiento.AutoSize = true;
            this.lblfechanacimiento.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfechanacimiento.Location = new System.Drawing.Point(36, 288);
            this.lblfechanacimiento.Name = "lblfechanacimiento";
            this.lblfechanacimiento.Size = new System.Drawing.Size(159, 20);
            this.lblfechanacimiento.TabIndex = 61;
            this.lblfechanacimiento.Text = "Fecha de Nacimiento";
            // 
            // Registropaciente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.Btncancelar);
            this.Controls.Add(this.BtnGuardar);
            this.Controls.Add(this.lblultivisita);
            this.Controls.Add(this.lblfechanacimiento);
            this.Controls.Add(this.txtApellido01);
            this.Controls.Add(this.lblApellido);
            this.Controls.Add(this.txtNombre01);
            this.Controls.Add(this.lblNombre);
            this.Controls.Add(this.txtpelaje);
            this.Controls.Add(this.txtsexo);
            this.Controls.Add(this.txtraza);
            this.Controls.Add(this.txtespecie);
            this.Controls.Add(this.txtpaciente);
            this.Controls.Add(this.lblpelaje);
            this.Controls.Add(this.lblsexo);
            this.Controls.Add(this.lblRaza);
            this.Controls.Add(this.lblespecie);
            this.Controls.Add(this.lblpaciente);
            this.Name = "Registropaciente";
            this.Text = "Registropaciente";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.TextBox txtApellido01;
        private System.Windows.Forms.Label lblApellido;
        public System.Windows.Forms.TextBox txtNombre01;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.TextBox txtpelaje;
        private System.Windows.Forms.TextBox txtsexo;
        private System.Windows.Forms.TextBox txtraza;
        private System.Windows.Forms.TextBox txtespecie;
        private System.Windows.Forms.TextBox txtpaciente;
        private System.Windows.Forms.Label lblpelaje;
        private System.Windows.Forms.Label lblsexo;
        private System.Windows.Forms.Label lblRaza;
        private System.Windows.Forms.Label lblespecie;
        private System.Windows.Forms.Label lblpaciente;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button Btncancelar;
        private System.Windows.Forms.Button BtnGuardar;
        private System.Windows.Forms.Label lblultivisita;
        private System.Windows.Forms.Label lblfechanacimiento;
    }
}