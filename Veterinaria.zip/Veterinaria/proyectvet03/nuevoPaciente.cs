﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace proyectvet03
{
    public partial class nuevoPaciente : Form
    {
        private DateTimePicker dateTimePicker1;
        private MaskedTextBox mtbultimavisita;
        private MaskedTextBox mtbfechaalta;
        private MaskedTextBox mtbfechanacimiento;
        public TextBox txtApellido01;
        private Label lblApellido;
        public TextBox txtNombre01;
        private Label lblNombre;
        private TextBox txtpelaje;
        private TextBox txtsexo;
        private TextBox txtraza;
        private TextBox txtespecie;
        private TextBox txtpaciente;
        private Button Btncancelar;
        private Button BtnGuardar;
        private Label lblultivisita;
        private Label lblpelaje;
        private Label lblfechaalta;
        private Label lblfechanacimiento;
        private Label lblsexo;
        private Label lblRaza;
        private Label lblespecie;
        private Label lblpaciente;

        public nuevoPaciente()
        {
            InitializeComponent();
           
           
        }


        private void btncancelar_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {

        }

        private void nuevoPaciente_Load(object sender, EventArgs e)
        {

        }

        private void InitializeComponent()
        {
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.mtbultimavisita = new System.Windows.Forms.MaskedTextBox();
            this.mtbfechaalta = new System.Windows.Forms.MaskedTextBox();
            this.mtbfechanacimiento = new System.Windows.Forms.MaskedTextBox();
            this.txtApellido01 = new System.Windows.Forms.TextBox();
            this.lblApellido = new System.Windows.Forms.Label();
            this.txtNombre01 = new System.Windows.Forms.TextBox();
            this.lblNombre = new System.Windows.Forms.Label();
            this.txtpelaje = new System.Windows.Forms.TextBox();
            this.txtsexo = new System.Windows.Forms.TextBox();
            this.txtraza = new System.Windows.Forms.TextBox();
            this.txtespecie = new System.Windows.Forms.TextBox();
            this.txtpaciente = new System.Windows.Forms.TextBox();
            this.Btncancelar = new System.Windows.Forms.Button();
            this.BtnGuardar = new System.Windows.Forms.Button();
            this.lblultivisita = new System.Windows.Forms.Label();
            this.lblpelaje = new System.Windows.Forms.Label();
            this.lblfechaalta = new System.Windows.Forms.Label();
            this.lblfechanacimiento = new System.Windows.Forms.Label();
            this.lblsexo = new System.Windows.Forms.Label();
            this.lblRaza = new System.Windows.Forms.Label();
            this.lblespecie = new System.Windows.Forms.Label();
            this.lblpaciente = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(376, 285);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 50;
            // 
            // mtbultimavisita
            // 
            this.mtbultimavisita.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mtbultimavisita.Location = new System.Drawing.Point(226, 344);
            this.mtbultimavisita.Mask = "00/00/0000";
            this.mtbultimavisita.Name = "mtbultimavisita";
            this.mtbultimavisita.Size = new System.Drawing.Size(100, 26);
            this.mtbultimavisita.TabIndex = 49;
            this.mtbultimavisita.ValidatingType = typeof(System.DateTime);
            // 
            // mtbfechaalta
            // 
            this.mtbfechaalta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mtbfechaalta.Location = new System.Drawing.Point(226, 311);
            this.mtbfechaalta.Mask = "00/00/0000";
            this.mtbfechaalta.Name = "mtbfechaalta";
            this.mtbfechaalta.Size = new System.Drawing.Size(100, 26);
            this.mtbfechaalta.TabIndex = 48;
            this.mtbfechaalta.ValidatingType = typeof(System.DateTime);
            // 
            // mtbfechanacimiento
            // 
            this.mtbfechanacimiento.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mtbfechanacimiento.Location = new System.Drawing.Point(226, 279);
            this.mtbfechanacimiento.Mask = "00/00/0000";
            this.mtbfechanacimiento.Name = "mtbfechanacimiento";
            this.mtbfechanacimiento.Size = new System.Drawing.Size(100, 26);
            this.mtbfechanacimiento.TabIndex = 47;
            this.mtbfechanacimiento.ValidatingType = typeof(System.DateTime);
            // 
            // txtApellido01
            // 
            this.txtApellido01.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtApellido01.Location = new System.Drawing.Point(606, 26);
            this.txtApellido01.Name = "txtApellido01";
            this.txtApellido01.Size = new System.Drawing.Size(171, 26);
            this.txtApellido01.TabIndex = 46;
            // 
            // lblApellido
            // 
            this.lblApellido.AutoSize = true;
            this.lblApellido.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblApellido.Location = new System.Drawing.Point(417, 29);
            this.lblApellido.Name = "lblApellido";
            this.lblApellido.Size = new System.Drawing.Size(125, 20);
            this.lblApellido.TabIndex = 45;
            this.lblApellido.Text = "Apellido Dueño :";
            // 
            // txtNombre01
            // 
            this.txtNombre01.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombre01.Location = new System.Drawing.Point(226, 26);
            this.txtNombre01.Name = "txtNombre01";
            this.txtNombre01.Size = new System.Drawing.Size(171, 26);
            this.txtNombre01.TabIndex = 44;
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre.Location = new System.Drawing.Point(37, 29);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(125, 20);
            this.lblNombre.TabIndex = 43;
            this.lblNombre.Text = "Nombre Dueño :";
            // 
            // txtpelaje
            // 
            this.txtpelaje.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpelaje.Location = new System.Drawing.Point(226, 237);
            this.txtpelaje.Name = "txtpelaje";
            this.txtpelaje.Size = new System.Drawing.Size(117, 26);
            this.txtpelaje.TabIndex = 42;
            // 
            // txtsexo
            // 
            this.txtsexo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsexo.Location = new System.Drawing.Point(226, 196);
            this.txtsexo.Name = "txtsexo";
            this.txtsexo.Size = new System.Drawing.Size(74, 26);
            this.txtsexo.TabIndex = 41;
            // 
            // txtraza
            // 
            this.txtraza.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtraza.Location = new System.Drawing.Point(226, 163);
            this.txtraza.Name = "txtraza";
            this.txtraza.Size = new System.Drawing.Size(117, 26);
            this.txtraza.TabIndex = 40;
            // 
            // txtespecie
            // 
            this.txtespecie.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtespecie.Location = new System.Drawing.Point(226, 120);
            this.txtespecie.Name = "txtespecie";
            this.txtespecie.Size = new System.Drawing.Size(117, 26);
            this.txtespecie.TabIndex = 39;
            // 
            // txtpaciente
            // 
            this.txtpaciente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpaciente.Location = new System.Drawing.Point(226, 80);
            this.txtpaciente.Name = "txtpaciente";
            this.txtpaciente.Size = new System.Drawing.Size(171, 26);
            this.txtpaciente.TabIndex = 38;
            // 
            // Btncancelar
            // 
            this.Btncancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btncancelar.Location = new System.Drawing.Point(357, 396);
            this.Btncancelar.Name = "Btncancelar";
            this.Btncancelar.Size = new System.Drawing.Size(98, 37);
            this.Btncancelar.TabIndex = 37;
            this.Btncancelar.Text = "SALIR";
            this.Btncancelar.UseVisualStyleBackColor = true;
            // 
            // BtnGuardar
            // 
            this.BtnGuardar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnGuardar.Location = new System.Drawing.Point(41, 396);
            this.BtnGuardar.Name = "BtnGuardar";
            this.BtnGuardar.Size = new System.Drawing.Size(98, 37);
            this.BtnGuardar.TabIndex = 36;
            this.BtnGuardar.Text = "Guardar";
            this.BtnGuardar.UseVisualStyleBackColor = true;
            // 
            // lblultivisita
            // 
            this.lblultivisita.AutoSize = true;
            this.lblultivisita.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblultivisita.Location = new System.Drawing.Point(37, 347);
            this.lblultivisita.Name = "lblultivisita";
            this.lblultivisita.Size = new System.Drawing.Size(97, 20);
            this.lblultivisita.TabIndex = 35;
            this.lblultivisita.Text = "Ultima Visita";
            // 
            // lblpelaje
            // 
            this.lblpelaje.AutoSize = true;
            this.lblpelaje.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpelaje.Location = new System.Drawing.Point(37, 237);
            this.lblpelaje.Name = "lblpelaje";
            this.lblpelaje.Size = new System.Drawing.Size(52, 20);
            this.lblpelaje.TabIndex = 34;
            this.lblpelaje.Text = "Pelaje";
            // 
            // lblfechaalta
            // 
            this.lblfechaalta.AutoSize = true;
            this.lblfechaalta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfechaalta.Location = new System.Drawing.Point(37, 309);
            this.lblfechaalta.Name = "lblfechaalta";
            this.lblfechaalta.Size = new System.Drawing.Size(108, 20);
            this.lblfechaalta.TabIndex = 33;
            this.lblfechaalta.Text = "Fecha de Alta";
            // 
            // lblfechanacimiento
            // 
            this.lblfechanacimiento.AutoSize = true;
            this.lblfechanacimiento.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfechanacimiento.Location = new System.Drawing.Point(37, 279);
            this.lblfechanacimiento.Name = "lblfechanacimiento";
            this.lblfechanacimiento.Size = new System.Drawing.Size(159, 20);
            this.lblfechanacimiento.TabIndex = 32;
            this.lblfechanacimiento.Text = "Fecha de Nacimiento";
            // 
            // lblsexo
            // 
            this.lblsexo.AutoSize = true;
            this.lblsexo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsexo.Location = new System.Drawing.Point(37, 196);
            this.lblsexo.Name = "lblsexo";
            this.lblsexo.Size = new System.Drawing.Size(42, 20);
            this.lblsexo.TabIndex = 31;
            this.lblsexo.Text = "sexo";
            // 
            // lblRaza
            // 
            this.lblRaza.AutoSize = true;
            this.lblRaza.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRaza.Location = new System.Drawing.Point(37, 163);
            this.lblRaza.Name = "lblRaza";
            this.lblRaza.Size = new System.Drawing.Size(47, 20);
            this.lblRaza.TabIndex = 30;
            this.lblRaza.Text = "Raza";
            // 
            // lblespecie
            // 
            this.lblespecie.AutoSize = true;
            this.lblespecie.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblespecie.Location = new System.Drawing.Point(37, 123);
            this.lblespecie.Name = "lblespecie";
            this.lblespecie.Size = new System.Drawing.Size(66, 20);
            this.lblespecie.TabIndex = 29;
            this.lblespecie.Text = "Especie";
            // 
            // lblpaciente
            // 
            this.lblpaciente.AutoSize = true;
            this.lblpaciente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpaciente.Location = new System.Drawing.Point(37, 83);
            this.lblpaciente.Name = "lblpaciente";
            this.lblpaciente.Size = new System.Drawing.Size(155, 20);
            this.lblpaciente.TabIndex = 28;
            this.lblpaciente.Text = "Nombre del paciente";
            // 
            // nuevoPaciente
            // 
            this.ClientSize = new System.Drawing.Size(822, 392);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.mtbultimavisita);
            this.Controls.Add(this.mtbfechaalta);
            this.Controls.Add(this.mtbfechanacimiento);
            this.Controls.Add(this.txtApellido01);
            this.Controls.Add(this.lblApellido);
            this.Controls.Add(this.txtNombre01);
            this.Controls.Add(this.lblNombre);
            this.Controls.Add(this.txtpelaje);
            this.Controls.Add(this.txtsexo);
            this.Controls.Add(this.txtraza);
            this.Controls.Add(this.txtespecie);
            this.Controls.Add(this.txtpaciente);
            this.Controls.Add(this.Btncancelar);
            this.Controls.Add(this.BtnGuardar);
            this.Controls.Add(this.lblultivisita);
            this.Controls.Add(this.lblpelaje);
            this.Controls.Add(this.lblfechaalta);
            this.Controls.Add(this.lblfechanacimiento);
            this.Controls.Add(this.lblsexo);
            this.Controls.Add(this.lblRaza);
            this.Controls.Add(this.lblespecie);
            this.Controls.Add(this.lblpaciente);
            this.Name = "nuevoPaciente";
            this.Text = "Nuevo Paciente";
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}
}
