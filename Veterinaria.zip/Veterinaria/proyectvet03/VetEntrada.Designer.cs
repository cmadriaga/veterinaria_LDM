﻿namespace proyectvet03
{
    partial class VetEntrada
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(VetEntrada));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnvisitas = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btncerrar = new System.Windows.Forms.Button();
            this.btnIngresarcanino = new System.Windows.Forms.Button();
            this.btnBuscarCanino = new System.Windows.Forms.Button();
            this.btnbuscarcliente = new System.Windows.Forms.Button();
            this.btnIngresarCliente = new System.Windows.Forms.Button();
            this.panelcontenedor = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(41, 373);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(76, 63);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 31;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click_1);
            // 
            // btnvisitas
            // 
            this.btnvisitas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnvisitas.Location = new System.Drawing.Point(41, 194);
            this.btnvisitas.Name = "btnvisitas";
            this.btnvisitas.Size = new System.Drawing.Size(99, 51);
            this.btnvisitas.TabIndex = 30;
            this.btnvisitas.Text = "Registro Visitas";
            this.btnvisitas.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(41, 134);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(99, 51);
            this.button1.TabIndex = 29;
            this.button1.Text = "Listar Cliente";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // btncerrar
            // 
            this.btncerrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncerrar.Location = new System.Drawing.Point(41, 442);
            this.btncerrar.Name = "btncerrar";
            this.btncerrar.Size = new System.Drawing.Size(118, 51);
            this.btncerrar.TabIndex = 28;
            this.btncerrar.Text = "Cerrar";
            this.btncerrar.UseVisualStyleBackColor = true;
            // 
            // btnIngresarcanino
            // 
            this.btnIngresarcanino.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIngresarcanino.Location = new System.Drawing.Point(41, 251);
            this.btnIngresarcanino.Name = "btnIngresarcanino";
            this.btnIngresarcanino.Size = new System.Drawing.Size(99, 51);
            this.btnIngresarcanino.TabIndex = 27;
            this.btnIngresarcanino.Text = "Ingresar Canino";
            this.btnIngresarcanino.UseVisualStyleBackColor = true;
            // 
            // btnBuscarCanino
            // 
            this.btnBuscarCanino.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarCanino.Location = new System.Drawing.Point(41, 316);
            this.btnBuscarCanino.Name = "btnBuscarCanino";
            this.btnBuscarCanino.Size = new System.Drawing.Size(99, 51);
            this.btnBuscarCanino.TabIndex = 26;
            this.btnBuscarCanino.Text = "Buscar Canino";
            this.btnBuscarCanino.UseVisualStyleBackColor = true;
            // 
            // btnbuscarcliente
            // 
            this.btnbuscarcliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbuscarcliente.Location = new System.Drawing.Point(41, 73);
            this.btnbuscarcliente.Name = "btnbuscarcliente";
            this.btnbuscarcliente.Size = new System.Drawing.Size(99, 51);
            this.btnbuscarcliente.TabIndex = 25;
            this.btnbuscarcliente.Text = "Buscar Cliente";
            this.btnbuscarcliente.UseVisualStyleBackColor = true;
            // 
            // btnIngresarCliente
            // 
            this.btnIngresarCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIngresarCliente.Location = new System.Drawing.Point(41, 16);
            this.btnIngresarCliente.Name = "btnIngresarCliente";
            this.btnIngresarCliente.Size = new System.Drawing.Size(99, 51);
            this.btnIngresarCliente.TabIndex = 24;
            this.btnIngresarCliente.Text = "Nuevo Cliente";
            this.btnIngresarCliente.UseVisualStyleBackColor = true;
            // 
            // panelcontenedor
            // 
            this.panelcontenedor.Location = new System.Drawing.Point(165, 16);
            this.panelcontenedor.Name = "panelcontenedor";
            this.panelcontenedor.Size = new System.Drawing.Size(761, 486);
            this.panelcontenedor.TabIndex = 32;
            // 
            // VetEntrada
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(981, 532);
            this.Controls.Add(this.panelcontenedor);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnvisitas);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btncerrar);
            this.Controls.Add(this.btnIngresarcanino);
            this.Controls.Add(this.btnBuscarCanino);
            this.Controls.Add(this.btnbuscarcliente);
            this.Controls.Add(this.btnIngresarCliente);
            this.Name = "VetEntrada";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnvisitas;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btncerrar;
        private System.Windows.Forms.Button btnIngresarcanino;
        private System.Windows.Forms.Button btnBuscarCanino;
        private System.Windows.Forms.Button btnbuscarcliente;
        private System.Windows.Forms.Button btnIngresarCliente;
        private System.Windows.Forms.Panel panelcontenedor;
    }
}

