﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace proyectvet03_01
{
    public class pacienteDAL
    {
        public static int Agregar(CPaciente ppaciente)
        {
            int retorno = 0;
            using (SqlConnection Conn = BDComun.ObtenerCOnexion())
            {
                SqlCommand comando = new SqlCommand(string.Format("Insert Into Paciente ( Nombre, Apellido, Paciente, especie, raza, sexo, pelaje , Fecha_nacimiento, Fecha_ultivis) Values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}')",
                    ppaciente.Nombre, ppaciente.Apellido,  ppaciente.paciente, ppaciente.especie, ppaciente.raza, ppaciente.sexo, ppaciente.pelaje, ppaciente.fechanacimiento,  ppaciente.fechaultimavisita), Conn);

                retorno = comando.ExecuteNonQuery();
            }
            return retorno;
        }

        public static List<CPaciente> BuscarPaciente(string pNombre)
        {
            List<CPaciente> Lista = new List<CPaciente>();
            using (SqlConnection conexion = BDComun.ObtenerCOnexion())
            {
                SqlCommand comando = new SqlCommand(string.Format("Select  Nombre, Apellido, paciente, especie, raza, sexo,  pelaje, Fecha_nacimiento, Fecha_ultivis from paciente where Nombre  like '%{0}%'", pNombre), conexion);
                SqlDataReader reader = comando.ExecuteReader();

                while (reader.Read())
                {
                    CPaciente ppaciente = new CPaciente();

                    ppaciente.Nombre = reader.GetString(0);
                    ppaciente.Apellido = reader.GetString(1);
                    ppaciente.paciente = reader.GetString(2);
                    ppaciente.especie = reader.GetString(3);
                    ppaciente.raza = reader.GetString(4);
                    ppaciente.sexo = reader.GetString(5);
                    ppaciente.pelaje = reader.GetString(6);
                    ppaciente.fechanacimiento = Convert.ToString(reader.GetString(7));
                    ppaciente.fechaultimavisita = Convert.ToString(reader.GetString(8));

                }

                conexion.Close();
                return Lista;


            }
        }
    }
}
